function init(){
    kozepre('bejelentkezes');
    kozepre('regisztracio');
    kozepre('rendeles');
}

function kozepre(mit){
    var x = window.innerWidth;
    var y = window.innerHeight;
    var ax = document.getElementById(mit).offsetWidth;
    var ay = document.getElementById(mit).offsetHeight;
    document.getElementById(mit).style.left = ((x - ax) / 2) + "px";
    document.getElementById(mit).style.top = ((y - ay) / 2) + "px"; 
}

function regnyit(){
    fnev.value = "";
    pwd.value = "";
    regisztracio.style.display = "block";
    bejelentkezes.style.display = "none";
    kozepre('regisztracio');
}

function regzar(){
    regnev.value = "";
    regfnev.value = "";
    pwd1.value = "";
    pwd2.value = "";
    bejelentkezes.style.display = "block";
    regisztracio.style.display = "none";
}

function rendelfelad(){
    rendeles.style.display = "block";
    kozepre('rendeles');
}

function megrendzar(){
    megrendnev.value = "";
    megrendcim.value = "";
    rendeles.style.display = "none";
}
function jelszoell() {
    if (pwd1.value == pwd2.value){
        regiszt.disabled = false;
    } else {
        regiszt.disabled = true;
    }
}

function kerespost(){
    var kuldendo = new FormData();
    kuldendo.append('nev', keres.value);
    var hivas = new XMLHttpRequest();
    hivas.open("POST", "./keres.php", true);
    hivas.onreadystatechange = function(){
        if(hivas.readyState == 4 && hivas.status == 200){
            talalat.innerHTML = hivas.responseText;
        }
    }

    hivas.send(kuldendo);
}

function keresget(){
    var hivas = new XMLHttpRequest();
    hivas.open("GET", "./keres.php?nev="+keres.value, true);
    hivas.onreadystatechange = function(){
        if(hivas.readyState == 4 && hivas.status == 200){
            talalat.innerHTML = hivas.responseText;
        }
    }

    hivas.send();
}

function kosarba(mit){
    var db = document.getElementById(mit).value;
    // !!!! document.getElementById(mit).value = 0;
    if (db == 0){
        alert("0 darabot nem rendelhet!");
    } else {
        var adatok = new FormData();
        adatok.append('id', mit);
        adatok.append('db', db);
        var httprequest = new XMLHttpRequest();
        httprequest.open("POST","./kosarba.php",true);
        httprequest.onreadystatechange = function(){
            if (httprequest.readyState == 4 && httprequest.status == 200){
                document.getElementById('kosar').innerHTML = httprequest.responseText;
            }
        }
        httprequest.send(adatok);
    }
}

function kosarmod(id, db){
    var httprequest = new XMLHttpRequest();
    httprequest.open("GET","./kosarmod.php?id="+id+"&db="+db,true);
    httprequest.onreadystatechange = function(){
        if (httprequest.readyState == 4 && httprequest.status == 200){
            document.getElementById('kosar').innerHTML = httprequest.responseText;
        }
    }
    httprequest.send();
}

function kosartorol(){
    var httprequest = new XMLHttpRequest();
    httprequest.open("GET","./kosartorol.php",true);
    httprequest.onreadystatechange = function(){
        if (httprequest.readyState == 4 && httprequest.status == 200){
            document.getElementById('kosar').innerHTML = httprequest.responseText;
        }
    }
    httprequest.send();
}
