<?php
    include './csatolt.php';
    $kep = $kapcsolat -> query("select tipus, kep from kepek where id=".$_GET['id']) -> fetch_assoc();
    header("Content-type: ".$kep['tipus']);
    echo $kep['kep'];
?>