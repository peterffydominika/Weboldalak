<?php
    include './csatolt.php';
?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Adatbázis</title>
</head>
<body>
    <h1>3. feladat</h1>
    <?php
        $sqlmondat = "select nev, orszag from allomas where orszag != \"\" order by nev";
        $eredmeny = $kapcsolat -> query($sqlmondat);
        if ($eredmeny -> num_rows == 0){
            //echo "<h2>Nincsen adat</h2>";
            ?>
            <h2>Nincsen adat</h2>
            <?php
        } else {
            ?>
            <table>
                <tr><th>Név</th><th>Ország</th></tr>
                <?php
                    while($rekord = $eredmeny -> fetch_assoc()){
                        echo "<tr><td>".$rekord['nev']."</td><td>".$rekord['orszag']."</td></tr>";
                    }
                ?>
            </table>
            <?php
        }
    ?>
    <h1>4. feladat</h1>
    <?php
        $sqlmondat = "select allomas.nev as allomasnev, allomas.tipus as allomastipus, hely.tav as tavolsag, hely.vonalid as vonal from allomas, hely where allomas.id=hely.allomasid and hely.vonalid='80' order by hely.tav";
        $eredmeny = $kapcsolat -> query($sqlmondat);
        if ($eredmeny -> num_rows == 0){
            //echo "<h2>Nincsen adat</h2>";
            ?>
            <h2>Nincsen adat</h2>
            <?php
        } else {
            ?>
            <table>
                <tr><th>Állomásnév</th><th>Tipus</th><th>Távolság</th><th>Vonal</th></tr>
                <?php
                    while($rekord = $eredmeny -> fetch_assoc()){
                        echo "<tr><td>".$rekord['allomasnev']."</td><td>".$rekord['allomastipus']."</td><td>".$rekord['tavolsag']."</td><td>".$rekord['vonal']."</td></tr>";
                    }
                ?>
            </table>
            <?php
        }
    ?>
</body>
</html>