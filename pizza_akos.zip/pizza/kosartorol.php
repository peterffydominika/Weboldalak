<?php
    include './csatolt.php';
    $kapcsolat -> query("delete kosar where felhid=".$_SESSION['id']);
    echo "A kosár üres...";
?>