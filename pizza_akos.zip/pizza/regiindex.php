<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>első program</title>
</head>
<body>
    <h1><?php echo "ez a főcím"; ?></h1>
    <?php
        
        $szoveges = "1. \"program\"<br>";
        echo $szoveges;
        
        $valtozo = 1;
        while($valtozo < 11){
            echo $valtozo."<br>"; 
            //$valtozo = $valtozo + 1;
            /*
            $valtozo += 1;
            */
            $valtozo++;
        }
        $valtozo = 1;
        do {
            echo $valtozo."<br>";
            $valtozo++;
        } while ($valtozo < 11);

        for ($valtozo = 1; $valtozo < 11; $valtozo++) echo $valtozo."<br>";

        $tomb = array(1,2,3.0,"almáspite",array("Skoda","Lada"));
        echo "a tömb elemeinek száma: ".count($tomb)."<br>";
        //for ($tombindex = 0;$tombindex < count($tomb); $tombindex++) echo $tomb[$tombindex]."<br>"; 
        //array_push(tombváltozó,elem1,...)
        //unset()

        foreach($tomb as $elem){
            if(gettype($elem) != "array"){
                echo $elem."<br>";
            } else {
                echo serialize($elem);
                foreach($elem as $kisebb) echo " - ".$kisebb."<br>";
            }
            //echo gettype($elem)."<br>";
            //isset(változó)
        }
    ?>
</body>
</html>
