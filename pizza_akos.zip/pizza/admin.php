<?php
    include './csatolt.php';

    $sqlmondat = "select * from felhasznalok where id<>".$_SESSION['id'];
    if (isset($_POST['torol'])){
        $felh = $_POST['felhasznalok'];
        $halmaz = "(";
        foreach ($felh as $value) {
            $halmaz .= $value.",";
        }
        $halmaz = rtrim($halmaz,",").")";
        $kapcsolat -> query("update felhasznalok set jog=3 where id in $halmaz");
    }

    if (isset($_POST["nevkeres"])){
        $nev = $_POST['nev'];
        $fnev = $_POST['fnev'];
        $jog = $_POST['jog'];
        if ($nev != ""){
            $sqlmondat .= " and nev like \"%$nev%\"";
        }
        if ($fnev != ""){
            $sqlmondat .= " and fnev like \"%$fnev%\"";
        }
        if ($jog > -1){
            $sqlmondat .= " and jog=$jog";
        }
    }
    $sqlmegrendkeres = "select * from megrendeles";
    if (isset($_POST["megrendkeres"])){
        $cimzett = $_POST["cimzett"];
        $cim = $_POST["cim"];
        $allapot = $_POST["mallapot"];
        if ($cimzett != ""){
            $poz = strpos($sqlmegrendkeres, "where");
            $sqlmegrendkeres .= "where nev like \"%$cimzett%\"";
        }
        if ($cim != ""){
            $poz = strpos($sqlmegrendkeres, "where");
            if ($poz == false){
                $sqlmegrendkeres .= " where";
            } else {
                $sqlmegrendkeres .= " and";
            }
            $sqlmegrendkeres .= " cim like \"%$cim%\"";
        }
        if ($allapot != -1){
            $poz = strpos($sqlmegrendkeres, "where");
            if ($poz == false){
                $sqlmegrendkeres .= " where";
            } else {
                $sqlmegrendkeres .= " and";
            }
            $sqlmegrendkeres .= " allapot=$allapot";
        }

    }
?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script>
        function allit(){
            var mire = mind.checked;
            var mit = document.getElementsByName("felhasznalok[]");
            for (var i = 0; i < mit.length; i++){
                mit[i].checked = mire;
            }
        }

        function jogvalt(kit, mire){
            var formData = new FormData();
            formData.append('kit',kit);
            formData.append('mire',mire);
            var request = new XMLHttpRequest();
            request.open("POST","./jogmodosit.php", true);
            request.send(formData);
        }

        function allapotvalt(mit, mire){
            var formData = new FormData();
            formData.append('mit',mit);
            formData.append('mire',mire);
            var request = new XMLHttpRequest();
            request.open("POST","./allapotmod.php", true);
            request.send(formData);
        }

        function mutat(mit){
            if(document.getElementById(mit).style.display == "none"){
                document.getElementById(mit).style.display = "block";
            } else {
                document.getElementById(mit).style.display = "none";
            }
        }
    </script>
    <style>
        .rejtett{
            display: none;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <?php
        if ($_SESSION['jog'] == 1){
        ?>
            <form action="" method="post">
                Név: <input type="text" name="nev" size="40" maxlength="40"><br>
                Felh. név: <input type="text" name="fnev" size="40" maxlength="40"><br>
                Jog: <select name="jog">
                    <option value="-1">Mind</option>
                    <option value="0">Regisztált</option>
                    <option value="1">Admin</option>
                    <option value="3">Törölt</option>
                </select><br>
                <input type="submit" value="Keres" name="nevkeres">
            </form>
    <?php
            $eredmeny = $kapcsolat -> query($sqlmondat);
            if ($eredmeny -> num_rows > 0) {
    ?>
            <form action="" method="post">
                <table>
                    <tr>
                        <th><input type='checkbox' id='mind' onchange="allit()"></th>
                        <th>Név</th>
                        <th>Felhasználói név</th>
                        <th>Jog</th>
                    </tr>
            <?php
                while ($felh = $eredmeny -> fetch_assoc()) {
                    $kiir = "<tr><td><input type='checkbox' name='felhasznalok[]' value='".$felh['id']."'></td><td>".$felh['nev']."</td><td>".$felh['fnev']."</td>";
                    if ($felh['jog'] == 0){
                        $kiir .= "<td><select onchange=\"jogvalt(".$felh['id'].", this.value)\"><option value=\"0\" selected>Regisztrál</option><option value=\"1\">Admin</option><option value=\"3\">Törölt</option></select></td>";
                    }
                    if ($felh['jog'] == 1){
                        $kiir .= "<td><select onchange=\"jogvalt(".$felh['id'].", this.value)\"><option value=\"0\">Regisztrál</option><option value=\"1\" selected>Admin</option><option value=\"3\">Törölt</option></select></td>";
                    }if ($felh['jog'] == 3){
                        $kiir .= "<td><select onchange=\"jogvalt(".$felh['id'].", this.value)\"><option value=\"0\">Regisztrál</option><option value=\"1\">Admin</option><option value=\"3\" selected>Törölt</option></select></td>";
                    }                  
                    $kiir .= "</tr>";
                    echo $kiir;
                }
            ?>
                    <tr><td colspan="3"><input type="submit" value="Töröl" name="torol"></td></tr>
                </table>
            </form>
    <?php
            } else {
                echo "<h1>Nincs kit törölni...</h1>";  
            }  
    ?>
            <h1>Rendelés állapotának módosítása keresés alapján</h1>
            <form action="" method="POST">
                <table>
                    <tr>
                        <td>Címzett neve:</td>
                        <td><input type="text" size="40" maxlength="40" name="cimzett"></td>
                    </tr>
                    <tr>
                        <td>Cím:</td>
                        <td><input type="text" size="60" maxlength="60" name="cim"></td>
                    </tr>
                    <tr>
                        <td>Megrendelés állapota:</td>
                        <td>
                            <select name="mallapot">
                                <option value="-1">Minden</option>
                                <option value="0">Megrendelve</option>
                                <option value="1">Feldolgozva</option>
                                <option value="2">Kiszállítva</option>
                                <option value="3">Törölve</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2"><input type="submit" value="Megrendelés keresése" name="megrendkeres"></td>
                    </tr>
                </table>    
            </form>
            <div id="megrendelesek">
    <?php 
        $eredmeny = $kapcsolat -> query($sqlmegrendkeres);
        if ($eredmeny -> num_rows > 0) {
            $valasz = "<table><tr><th>Címzett</th><th>Cím</th><th>Állapot</th></tr>";
            while ($sor = $eredmeny -> fetch_assoc()) {
                $valasz .= "<tr><td onclick=\"mutat(".$sor['id'].")\">".$sor['nev']."</td><td>".$sor['cim']."</td><td>";
                if ($sor['allapot'] == 0){
                    $valasz .= "<select onchange=\"allapotvalt(".$sor['id'].", this.value)\"><option value=\"0\" selected>Megrendelve</option><option value=\"1\">Feldolgozva</option><option value=\"2\">Kiszállítva</option><option value=\"3\">Törölve</option></select>";
                }
                if ($sor['allapot'] == 1){
                    $valasz .= "<select onchange=\"allapotvalt(".$sor['id'].", this.value)\"><option value=\"0\">Megrendelve</option><option value=\"1\" selected>Feldolgozva</option><option value=\"2\">Kiszállítva</option><option value=\"3\">Törölve</option></select>";
                }
                if ($sor['allapot'] == 2){
                    $valasz .= "<select onchange=\"allapotvalt(".$sor['id'].", this.value)\"><option value=\"0\">Megrendelve</option><option value=\"1\">Feldolgozva</option><option value=\"2\" selected>Kiszállítva</option><option value=\"3\">Törölve</option></select>";
                }
                if ($sor['allapot'] == 3){
                    $valasz .= "<select onchange=\"allapotvalt(".$sor['id'].", this.value)\"><option value=\"0\">Megrendelve</option><option value=\"1\">Feldolgozva</option><option value=\"2\">Kiszállítva</option><option value=\"3\" selected>Törölve</option></select>";
                }
                $valasz .= "</td></tr>";
                $valasz .= "<tr><td></td><td colspan=\"2\"><div class=\"rejtett\" id=\"".$sor['id']."\">";
                $pizzak = $kapcsolat -> query("SELECT nev, db FROM rendeles, kepek WHERE rendeles.pizzaid=kepek.id and megrendid=".$sor['id']);
                while ($pizza = $pizzak -> fetch_assoc()) {
                    $valasz .= $pizza['nev']." - ".$pizza['db']."db<br>";
                }
                $valasz .= "</div></td></tr>";
            }
            echo $valasz."</table>";
        } else {
            echo "<h1>Nincsen a feltételnek megfelelő lekérdezés...</h1>";
        }
    ?></div>
    <?php
        } else {
            echo "<h1>Nincs jogosultsága az oldalhoz...</h1>";
        }
    ?>

    <div>
        <ol>
            <li>Rendelés állapotának módosítása keresés alapján</li>
            <li>Rendelés nyomonkövetése és/vagy törlése</li>
        </ol>
    </div>
</body>
</html>