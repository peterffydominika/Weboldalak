<?php
    include './csatolt.php';
    if ($_SESSION['jog'] == 1){
        $kit = $_POST['kit'];
        $mire = $_POST['mire'];
        $kapcsolat -> query("update felhasznalok set jog=$mire where id=$kit");
    }
?>