<?php
    include './csatolt.php';
    $jelszo = sha1("jelszo");
    $sqlmondat = "INSERT INTO felhasznalok(id, nev, fnev, jelszo) VALUES (0,'Mekk Elek','elek@elek.hu','$jelszo')";
    $kapcsolat -> query($sqlmondat);
?>