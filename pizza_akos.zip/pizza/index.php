<?php
    include './csatolt.php';
    
    $uzenet = "";
    $fnev="";
    if(isset($_POST['belep'])){
        $fnev = strtolower($_POST['fnev']);
        $jelszo = sha1($_POST['pwd']);
        //jog=3 azt jelenti, hogy a felhasználót felgüggesztettük/töröltük
        $eredmeny = $kapcsolat -> query("select * from felhasznalok where fnev='$fnev' and jelszo='$jelszo' and jog<>3");
        if ($eredmeny -> num_rows == 0){
            $uzenet = "Hibás felhasználói név, vagy jelszóm vagy törölt...";
        } else {
            $felhasznalo = $eredmeny->fetch_assoc();
            $_SESSION['id'] = $felhasznalo['id'];
            $_SESSION['nev'] = $felhasznalo['nev'];
            $_SESSION['jog'] = $felhasznalo['jog'];
        }
    }

    if(isset($_POST['kilep'])){
        $_SESSION['id'] = 0;
        $_SESSION['nev'] = "";
        $_SESSION['jog'] = 0;
    }

    if (isset($_POST['regiszt'])){
        $_SESSION['id'] = 0;
        $_SESSION['nev'] = "";
        $_SESSION['jog'] = 0;
        $nev = $_POST['nev'];
        $fnev = strtolower($_POST['fnev']);
        $jelszo = sha1($_POST['pwd1']);
        if ($kapcsolat -> query("select * from felhasznalok where fnev='$fnev'") -> num_rows != 0){
            $uzenet = "Ez a felhasználói név ($fnev) már foglalt.";
        } else {
            $kapcsolat -> query("INSERT INTO felhasznalok(id, nev, fnev, jelszo) VALUES (0,'$nev','$fnev','$jelszo')");
            $_SESSION['id'] = $kapcsolat -> insert_id;
            $_SESSION['nev'] = $nev;
            $_SESSION['jog'] = 0;
        }
    }

    if (isset($_POST['megrendcim'])){
        $nev = $_POST['megrendnev'];
        $cim = $_POST['megrendcim'];
        $megrendid = $_SESSION['id'];
        $eredmeny = $kapcsolat -> query("select * from kosar where felhid=".$_SESSION['id']);
        if ($eredmeny -> num_rows == 0){
            $uzenet = "A kosár eltűnt";
        } else {
            $kapcsolat -> query("INSERT INTO megrendeles(id, megrendid, nev, cim) VALUES (0,$megrendid,'$nev','$cim')");
            $rendid = $kapcsolat -> insert_id;
            
            while ($rekord =$eredmeny -> fetch_assoc()) {
                $kapcsolat -> query("INSERT INTO rendeles(megrendid, pizzaid, db) VALUES ($rendid,'".$rekord['pizzaid']."','".$rekord['db']."')");
            }
            $kapcsolat -> query("delete from kosar where felhid=".$_SESSION['id']);
            $uzenet = "Sikeres megrendelés";
        }
    }
?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="./stilus.css">
    <script src="./js.js"></script>
</head>
<body onload="init()" onresize="init()">
    <form method="post" action="">
    <?php 
        if($_SESSION['id'] == 0) {
            echo $uzenet;
        } else {
            echo "Bejelentkezett, mint ".$_SESSION['nev'];
            echo "<input type=\"submit\" value=\"Kilépés\" name=\"kilep\">";
        } 
    ?>
    </form>
    <?php
        if ($_SESSION['id'] == 0){
    ?>
    <div id="bejelentkezes">
        <form method="POST" action="">
            <table>
                <tr><th colspan="2">Bejelentkezés</th></tr>
                <tr><td>e-mail cím: </td><td><input type="email" name="fnev" id="fnev" value="<?php echo $fnev; ?>" size="40" required></td></tr>
                <tr><td>jelszó: </td><td><input type="password" name="pwd" id="pwd" size="40" required></td></tr>
                <tr>
                    <td colspan="2">
                        <input type="submit" value="Belépés" name="belep">
                        <input type="button" value="Regisztráció" onclick="regnyit()">
                    </td>
                </tr>
            </table>
        </form>
    </div>
    <div id="regisztracio">
        <form method="post" action="">
        <table>
                <tr><th colspan="2">Regisztráció</th></tr>
                <tr>
                    <td>Név: </td><td><input type="text" name="nev" id="regnev" size="40" required></td>
                </tr>
                <tr>
                    <td>e-mail cím: </td><td><input type="email" name="fnev" id="regfnev" size="40" required></td>
                </tr>
                <tr>
                    <td>jelszó: </td><td><input type="password" name="pwd1" id="pwd1" size="40" onchange="jelszoell()" required></td>
                </tr>
                <tr>
                    <td>újra: </td><td><input type="password" name="pwd2" id="pwd2" size="40" onchange="jelszoell()" required></td>
                </tr>
                <tr>
                    <td colspan="2">
                        <input type="submit" value="Regisztráció" name="regiszt" id="regiszt" disabled>
                        <input type="button" value="Mégse" onclick="regzar()">
                    </td>
                </tr>
            </table>
        </form>
    </div>
    <?php
        } else {
    ?>
            <h2>A kosár tartalma:</h2>
            <div id="kosar">
                <?php
                    if ($uzenet != ""){
                        echo "<h1>".$uzenet."</h1>";
                    } else {
                        kosaram(); 
                    }
                ?>
            </div>
            <div id="rendeles">
                <form method="POST" action="">
                    <table>
                        <tr><th colspan="2"></th></tr>
                        <tr>
                            <td>Megrendelő neve:</td>
                            <td><input type="text" size="40" maxlength="40" name="megrendnev" id="megrendnev" value="<?php echo $_SESSION['nev']; ?>" required></td>
                        </tr>
                        <tr>
                            <td>Megrendelő címe:</td>
                            <td><input type="text" size="60" maxlength="60" name="megrendcim" id="megrendcim" value="" required></td>
                        </tr>
                        <tr>
                            <td><input type="submit" value="Megrendelés feladása" name="megrendel"></td>
                            <td><input type="button" onclick="megrendzar()" value="Mégse"></td>
                        </tr>
                    </table>
                </form>
            </div>
            <div class="kontener">
            <?php
                $eredmeny = $kapcsolat -> query("select id, nev from kepek order by nev");
                if ($eredmeny -> num_rows > 0){
                    while ($rekord = $eredmeny -> fetch_assoc()){
                ?>
                <div class="doboz">
                    <img class="pizzakep" src="./kepnezo.php?id=<?php echo $rekord['id']; ?>">
                    <div><?php echo $rekord['nev']; ?></div>
                    <div>
                        <input type="number" min="0" max="99" value="0" id="<?php echo $rekord['id']; ?>">
                        <img src="./kepek/kosar.png" onclick="kosarba(<?php echo $rekord['id']; ?>)">
                    </div>
                </div>
                <?php
                    }
                }
            ?>
            </div>
    <?php
        }
    ?>
</body>
</html>
