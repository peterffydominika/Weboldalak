<?php
    include './csatolt.php';
    if ($_SESSION['id'] > 0){
        $id = $_GET['id'];
        $db = $_GET['db'];

        if ($db == 0){
            $kapcsolat -> query("delete from kosar where felhid=".$_SESSION['id']." and pizzaid=$id");
        } else {
            $kapcsolat -> query("update kosar set db=$db where felhid=".$_SESSION['id']." and pizzaid=$id");
        }
        kosaram();
    } else {
        echo "Nem jelentkezett be...";
    }
?>