<?php
    include './csatolt.php';
    if ($_SESSION['id'] > 0){
        $id = $_POST['id'];
        $db = $_POST['db'];

        //megnézzük, hogy van-e a kosárban...
        if ($kapcsolat -> query("select * from kosar where felhid=".$_SESSION['id']." and pizzaid=$id") -> num_rows > 0){
            //update, mert talált
            $kapcsolat -> query("update kosar set db=db+$db where felhid=".$_SESSION['id']." and pizzaid=$id");
        } else {
            //insert , mert nincsen
            $kapcsolat -> query("INSERT INTO kosar(felhid, pizzaid, db) VALUES (".$_SESSION['id'].",$id,$db)");
        }

        kosaram();
    } else {
        echo "Nem jelentkezett be...";
    }
?>