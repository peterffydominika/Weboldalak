<?php
    include './csatolt.php';
    if ($_SESSION['jog'] == 1){
        $mit = $_POST['mit'];
        $mire = $_POST['mire'];
        $kapcsolat -> query("update megrendeles set allapot=$mire where id=$mit");
    }
?>