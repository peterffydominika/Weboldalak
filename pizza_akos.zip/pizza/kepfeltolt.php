<?php
    include './csatolt.php';

    if (isset($_POST['feltolt'])){
        if (count($_FILES) > 0){
            if(is_uploaded_file($_FILES['kep']['tmp_name'])){
                $nev = $_POST['nev'];
                $kep = $_FILES['kep']['tmp_name'];
                $tipus = mime_content_type(($kep));
                $kep = addslashes(file_get_contents($kep));
                $kapcsolat -> query("insert into kepek values(0,'$nev','$tipus','$kep')");
            }
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form method="POST" action="" enctype="multipart/form-data">
        Név: <input type="text" name="nev" size="50" maxlength="50"><br>
        Kép: <input type="file" name="kep">
        <input type="submit" value="Feltöltés" name="feltolt">

    </form>
</body>
</html>