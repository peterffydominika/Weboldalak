<?php
    if(session_status() == PHP_SESSION_NONE) session_start();

    if(!isset($_SESSION['id'])) $_SESSION['id'] = 0;
    if(!isset($_SESSION['nev'])) $_SESSION['nev'] = "";
    if(!isset($_SESSION['jog'])) $_SESSION['jog'] = 0;

    $szerver = "localhost";
    $felhasznalo = "root";
    $jelszo = "";
    $adatbazis = "pizza";

    $kapcsolat = new mysqli($szerver,$felhasznalo,$jelszo,$adatbazis);

    function kosaram(){
        $kapcsolat2 = new mysqli("localhost","root","","pizza");
        $kosar = $kapcsolat2->query("select * from kosar where felhid=".$_SESSION['id']);

        if($kosar -> num_rows > 0){
            $valasz = "";
            while ($elem = $kosar -> fetch_assoc()){
                $eredmeny = $kapcsolat2 -> query("select nev from kepek where id=".$elem['pizzaid']);
                $rekord = $eredmeny -> fetch_assoc();
                $valasz .= ($rekord['nev']." <input type=\"number\" value=\"".$elem['db']."\" min=\"0\" max=\"99\" step=\"1\" onchange=\"kosarmod(".$elem['pizzaid'].",this.value)\">db<br>");
            }
            $valasz .= "<input type=\"button\" value=\"Kosár törlése\" onclick=\"kosartorol()\"><input type=\"button\" value=\"Rendelés feladása\" onclick=\"rendelfelad()\">";
            echo $valasz;
        } else {
            echo "A kosár üres!";
        }
    }
?>