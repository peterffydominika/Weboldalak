<?php
    setcookie("cookieneve","újérték",time()+3600,"/");

    if (isset($_COOKIE['cookieneve'])) echo $_COOKIE['cookieneve'];
?>