<?php
    include './csatolt.php';
    if ($_SESSION['jog'] != 1){
        echo "Nincs joga keresni!";
    } else {
        if(isset($_POST['nev'])){
            $nev = $_POST['nev'];
        } else {
            $nev = $_GET['nev'];
        }
        $eredmeny = $kapcsolat -> query("select * from felhasznalok where nev like \"%$nev%\" order by nev");
        if ($eredmeny -> num_rows == 0){
            echo "Nincs találat...";
        } else  {
            $valasz = "";
            while ($adat = $eredmeny -> fetch_assoc()){
                $valasz .= ($adat['nev']." (".$adat['fnev'].")<br>");
            }
            echo $valasz;
        }
    }
?>